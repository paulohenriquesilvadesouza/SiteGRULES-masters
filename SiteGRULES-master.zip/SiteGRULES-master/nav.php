<nav class="navbar navbar-static-top">
        <div class="container" align="center">
        <ul class="nav nav-pills">
        <li role="presentation" class="active"><a href="painel.php">Home</a></li>
        <li role="presentation"><a href="alunos.php">Alunos</a></li>
        <li role="presentation"><a href="evento.php">Evento</a></li>
        <li role="presentation"><a href="apresentacao.php">Apresentação</a></li>
        <li role="presentation"><a href="http://vest.doctum.edu.br/unidade/ipatinga/">Contato</a></li>
        <a class="nav-link btn btn-danger" href="index.php">Sair</a>
        </ul>
        
        </div>
</nav>