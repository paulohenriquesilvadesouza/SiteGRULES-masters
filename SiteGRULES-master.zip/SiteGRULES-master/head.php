<!DOCTYPE html>
<html lang="pt-br">
<head>
    
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> GRULES &copy </title>
        <link rel="icon" type="image/png" href="img/logo.png">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="print.css" type="text/css" media="print">
        <link href="css/font.css" rel="stylesheet">
		<link rel="stylesheet" href="lib\css\fontawesome-all.css" >

        <!-- CSS
        <link rel="stylesheet" type="text/css" href="css/modelo.css"> -->
    
</head>

<!-- <body background="img/Background-composers.jpg" bgproperties="fixed" background-repeat="no repeat" width=100%> -->

<body background="img/5912.jpg" background-repeat="no repeat" class="img-responsive">